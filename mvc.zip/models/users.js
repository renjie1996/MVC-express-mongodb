// lib/mongo.js 是表设计
// M层的代码 CRUD-增删改查
// 数据业务层
// 跟数据打交道

//送数据进来
const User = require('../lib/mongo').User



    // 数据送达已经完成,mongolass来执行数据库操作

    // exec 执行操作
    // user json 表单里提交的数据，组装成一个user
    // 接受json object
    // mongodb存放 json文档 的数据库
    // create是mongolass对mongodb的insert的方法封装API
    // 将返回结果返回出去 
    // 失败 格式 重名 。。。


    // 查询服务提供，根据名字返回用户信息

module.exports = {
  
  create: function create(user) {
    return User.create(user).exec()
  },


  getUserByName: function getUserByName(name) {
    return User
      .findOne({ name:name})
      .exec()
  }
}