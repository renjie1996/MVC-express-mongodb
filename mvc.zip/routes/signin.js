//登录的路由模块
//Router对象 交给应用层级的路由，渲染成路由中间件
//路由中间件，匹配的过程，路由的path
const express = require('express')
const router = express.Router()
router.get('/',(req, res, next)=>{
  res.render('signin')
})

router.post('/',(res, req, next)=>{
  
})



module.exports = router