const routes = require('./routes')
const pkg = require('./package.json')
// express是一个基于中间件的web开发框架
// 从用户请求到响应，提供服务，串联起来
// session中间件 验证用户身份
// flash中间件 警示信息
// 连接数据库中间件 文件上传中间件
const path = require('path')
const express = require('express')

//项目配置中间件，配置是模块 管理配置信息
const config = require('config-lite')
//错误提示中间件
const flash = require('connect-flash')
const session = require('express-session')
//post 处理表单 的中间件
const formidable = require('express-formidable')
//mongodb中间件 ，没有用cookie，session是相当于用户识别信息，长期保存内存信息，内存中易丢失，用的是session 存放在mongodb
const MongoStore = require('connect-mongo')(session)

const app = express()
console.log(pkg.name);
console.log(pkg.description);

//__dirname当前目录
//设置mvc的v的位置
//一样的
// app.set('./views',path.join(__dirname, './views'));
// app.set('view engine','ejs');
//模版引擎
app.set('views',path.join(__dirname, 'views'))
app.set('view engine','ejs')

//模块全局变量，全局变量放在locals下
app.locals.wukong = {
  title: pkg.name,
  description: pkg.description
}
app.use(flash())

app.use(formidable({
  //表单处理的中间件使用并配置
  //文件上传
    uploadDir: path.join(__dirname, 'public/img'),
    keepExtensions: true
}))

//启用了flash中间件，他是有依赖的
app.use(session({
  name: 'wukong',
  secret: 'xrj19960317',
  resave: true,
  //未登录强制分配，强制分配session，分配一个唯一的时间戳
  saveUninitialized: false,
  cookie: {
    //session持续多久
    mexAge: 86400
  }
}))

//req负责请求对象，
//res负责结果输出，
//next传给下个中间件
//给所有模版添加



app.use((req,res,next)=>{
  res.locals.error = req.flash('error').toString()
  console.log('res.locals.error')
  next()
})
// app.get('/',(req,res) => {
//   res.send('Express is servering')
// })
routes(app)
// app.get('/',RouterIndex)

app.listen(3002,()=>{
  console.log('Listening on port:3002:')
})

