//commonjs模块化机制
module.exports = function(app) {
  app.get('/',(req, res)=>{
    console.log('render')
    req.flash('error','你猜我报不报错')
    res.render('post',{})
  })

//get是根目录下的，路径级别的中间件
//use应用级别的中间件 路由中间件 击花传鼓使用
  app.use('/signin',require('./signin'))
  app.use('/signup',require('./signup'))
}

