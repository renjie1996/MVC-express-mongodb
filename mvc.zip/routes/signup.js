//注册的路由模块
//Router对象 交给应用层级的路由，渲染成路由中间件
//路由中间件，匹配的过程，路由的path
const express = require('express')
const router = express.Router()

//调用model，操作数据层,才是controller目的之一
const UserModel = require('../models/users')

router.get('/',(req, res, next)=>{
  res.render('signup')
})
router.post('/', (req, res, next) => {
  //formidable 会把所有请求包含在fields上
    // console.log(req.fields)
    let name = req.fields.name,
        gender = req.fields.gender,
        bio = req.fields.bio,
        password = req.fields.password,
        repassword = req.fields.repassword,
        user = {
          name ,
          password,
          repassword,
          gender,
          bio
        }

        //返回一个promise链
    UserModel
      .create(user)
      .then((result)=>{
        console.log(result)
      })
    // console.log(user)

    //controller层 将user保存进去

})




module.exports = router